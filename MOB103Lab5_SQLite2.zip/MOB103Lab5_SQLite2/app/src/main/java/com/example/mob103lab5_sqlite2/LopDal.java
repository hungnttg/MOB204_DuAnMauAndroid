package com.example.mob103lab5_sqlite2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class LopDal {

    private Context context;
    SQLiteHelper sqLiteHelper;
    SQLiteDatabase db;
    public static final String SQL_TAOBANG_LOP = "CREATE TABLE Lop (" +
            " MaLop text primary key," +
            " TenLop text)";
    public static final String TABLE_NAME_LOP = "Lop";
    public LopDal(Context context)
    {
        sqLiteHelper = new SQLiteHelper(context);//tao DB
        db = sqLiteHelper.getWritableDatabase();//cho phep ghi
    }

    public int insertLop(Lop lop)
    {
        ContentValues values = new ContentValues();
        values.put("MaLop",lop.getMaLop());
        values.put("TenLop",lop.getTenLop());
        if(db.insert(TABLE_NAME_LOP,null,values)<0)
        {

            return -1; //insert khong thanh cong
        }
        return 1; //insert thanh cong
    }
    public List<Lop> getAllLop()
    {
        List<Lop> list = new ArrayList<Lop>();
        Cursor cursor = db.query(TABLE_NAME_LOP,null,null,null,null,null,null);
        cursor.moveToFirst();
        while (cursor.isAfterLast()==false)
        {
            Lop lop = new Lop();
            lop.setMaLop(cursor.getString(0));
            lop.setTenLop(cursor.getString(1));
            list.add(lop);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public List<String> getAllMaLop()
    {
        List<String> list = new ArrayList<String>();
        Cursor cursor = db.query(TABLE_NAME_LOP,null,null,null,null,null,null);
        cursor.moveToFirst();
        while (cursor.isAfterLast()==false)
        {
            Lop lop = new Lop();
            //lop.setMaLop(cursor.getString(0));
            lop.setMaLop(cursor.getString(0));
            list.add(lop.getMaLop());
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

}

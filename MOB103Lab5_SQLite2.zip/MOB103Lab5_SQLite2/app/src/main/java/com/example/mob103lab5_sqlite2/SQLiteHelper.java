package com.example.mob103lab5_sqlite2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "QLSV";
    public static final int VERSION =1;

    //tao db
    public SQLiteHelper(Context context) {
        super(context, DB_NAME, null, VERSION);
    }
    //tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(LopDal.SQL_TAOBANG_LOP);
    }
    //cap nhap bang du lieu
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS "+LopDal.TABLE_NAME_LOP);//xoa bang neu da ton tai
    }
}

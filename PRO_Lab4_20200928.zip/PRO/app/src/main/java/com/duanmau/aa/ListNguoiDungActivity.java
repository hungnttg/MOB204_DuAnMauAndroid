package com.duanmau.aa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.duanmau.aa.adapter.NguoiDungAdapter;
import com.duanmau.aa.dao.NguoiDungDao;
import com.duanmau.aa.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class ListNguoiDungActivity extends AppCompatActivity {
    Intent intent;
    public static List<NguoiDung> lsND;
    ListView lvNguoiDung;
    NguoiDungDao nguoiDungDao;
    NguoiDungAdapter ndAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nguoi_dung);
        lvNguoiDung = findViewById(R.id.lvNguoiDung);
        nguoiDungDao = new NguoiDungDao(ListNguoiDungActivity.this);
        lsND = nguoiDungDao.getAllNguoiDung();
        ndAdapter = new NguoiDungAdapter(this,lsND);
        lvNguoiDung.setAdapter(ndAdapter);
        lvNguoiDung.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 intent = new Intent(ListNguoiDungActivity.this,DetailNguoiDungActivity.class);
                 Bundle b = new Bundle();
                 b.putString("username",lsND.get(position).getUsername());
                b.putString("password",lsND.get(position).getPassword());
                b.putString("phone",lsND.get(position).getPhone());
                b.putString("hoten",lsND.get(position).getHoten());
                intent.putExtras(b);
                startActivity(intent);
            }
        });
    }
    public void startThemNguoiDung(View view)
    {
        intent = new Intent(ListNguoiDungActivity.this,NguoiDungActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        lsND.clear();//xoa cai cu
        lsND = nguoiDungDao.getAllNguoiDung();//lay lai cai moi
        ndAdapter.changeDataset(lsND);
    }
}

package com.edu.fpoly.bookmanager.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.edu.fpoly.bookmanager.ListNguoiDungActivity;
import com.edu.fpoly.bookmanager.NguoiDungActivity;
import com.edu.fpoly.bookmanager.R;
import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.List;

public class NguoiDungRecyclerAdapter extends RecyclerView.Adapter<NguoiDungRecyclerAdapter.RecyclerHolderView> {
    private Context context;
    private List<NguoiDung> arrNguoiDung;
    private LayoutInflater inflater;
    NguoiDungDAO nguoiDungDAO;
    public NguoiDungRecyclerAdapter(Context context, List<NguoiDung> arrNguoiDung)
    {

        this.context = context;
        this.arrNguoiDung = arrNguoiDung;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        nguoiDungDAO = new NguoiDungDAO(context);
    }

    @Override
    public int getItemCount() {
        return arrNguoiDung.size();
    }

    //gan du lieu
    @Override
    public void onBindViewHolder(RecyclerHolderView recyclerHolderView, final int position) {
        NguoiDung nguoiDung = arrNguoiDung.get(position);
        recyclerHolderView.tvName.setText(nguoiDung.getUserName());
        recyclerHolderView.tvPhone.setText(nguoiDung.getPhone());


    }
    //tao view
    @Override
    public RecyclerHolderView onCreateViewHolder(ViewGroup viewGroup, final int i) {
        View view = inflater.inflate(R.layout.item_nguoi_dung,null);
        RecyclerHolderView  view1 = new RecyclerHolderView(view);
        view1.ivIcon = (ImageView)view.findViewById(R.id.ivIcon);
        view1.tvName = (TextView)view.findViewById(R.id.tvName);
        view1.tvPhone = (TextView)view.findViewById(R.id.tvPhone);
        view1.ivDelete = (ImageView)view.findViewById(R.id.ivDelete);


        return view1;
    }



    public class RecyclerHolderView extends RecyclerView.ViewHolder{

        ImageView ivIcon;
        TextView tvName;
        TextView tvPhone;
        ImageView ivDelete;

        public RecyclerHolderView(View itemView) {
            super(itemView);
            this.ivIcon = ivIcon;
            this.tvName = tvName;
            this.tvPhone = tvPhone;
            this.ivDelete = ivDelete;
        }
    }
}

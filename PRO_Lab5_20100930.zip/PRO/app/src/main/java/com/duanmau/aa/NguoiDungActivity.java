package com.duanmau.aa;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.duanmau.aa.dao.NguoiDungDao;
import com.duanmau.aa.model.NguoiDung;

public class NguoiDungActivity extends AppCompatActivity {
    Button btnThemNguoiDung;
    NguoiDungDao nguoiDungDao;
    EditText edUser, edPass, edRepass, edPhone, edFullname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nguoi_dung);
        setTitle("Them Nguoi Dung");
        btnThemNguoiDung = findViewById(R.id.btnAddUser);
        edUser = findViewById(R.id.edUserName);
        edPass = findViewById(R.id.edPassword);
        edRepass = findViewById(R.id.edRePassword);
        edPhone = findViewById(R.id.edPhone);
        edFullname = findViewById(R.id.edFullName);
    }

    public void addUser(View view) {
        nguoiDungDao = new NguoiDungDao(NguoiDungActivity.this);
        //create an user with the data input from the keyboard
        NguoiDung u = new NguoiDung(edUser.getText().toString(),
                edPass.getText().toString(),
                edPhone.getText().toString(),
                edFullname.getText().toString());
        try {
            if(nguoiDungDao.insertNguoiDung(u)>0)
            {
                Toast.makeText(getApplicationContext(),"Insert successful",Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Insert not successful",Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e)
        {
            Log.e("Error: ",e.getMessage());
        }

    }

    public void showUsers(View view) {
        finish();
    }
}

package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class NguoiDungDAO {
    //su dung bien csdl
    private SQLiteDatabase db;
    //su dung phan helper vua dinh nghia
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME = "NguoiDung";//ten bang
    //chuoi tao bang nguoi dung
    public static final String SQL_NGUOIDUNG = "CREATE TABLE NguoiDung (" +
            " userName text primary key, " +
            " password text, " +
            " phone text, " +
            " fullName text );";
    //viet phuong thuc khoi tao
    public NguoiDungDAO(Context context)
    {
        //tao moi dbhelper
        dbHelper = new DatabaseHelper(context);
        //cho phep ghi vao bang du lieu
        db =dbHelper.getWritableDatabase();
    }
    //ham insert nguoi dung
    public int insertNguoiDung(NguoiDung nd)
    {
        ContentValues values = new ContentValues();//doi tuong chua du lieu
        values.put("userName",nd.getUserName());//dua username vao doi tuong value
        values.put("password",nd.getPassword());//dua pas vao doi tuong value
        values.put("phone",nd.getPhone());//dua phone vao doi tuong value
        values.put("fullName",nd.getFullName());//dua fullname vao doi tuong value
        try {
            if(db.insert(TABLE_NAME,null,values)==-1)//thuc hien insert
            {
                return -1;//insert khong thanh cong
            }
            else
            {
                return 1;//insert thanh cong
            }
        }
        catch (Exception e)
        {
            Log.e("NguoiDung",e.getMessage());//thong bao loi
        }
        return 1;//insert thanh cong
    }
    public List<NguoiDung> getAllNguoiDung()
    {
        //tao 1 list de chua nguoi dung
        List<NguoiDung> arrNguoiDung = new ArrayList<>();
        //truy van du lieu
        Cursor c =db.query(TABLE_NAME,null,null,null,
                null,null,null,null);
        //di chuyen ve ban ghi dau tien
        c.moveToFirst();
        while (c.isAfterLast()==false)// khi khong phai ban ghi cuoi cung thi moi doc
        {
            //tao 1 nguoi dung
            NguoiDung nguoiDung = new NguoiDung();
            nguoiDung.setUserName(c.getString(0));//doc truong so 0 dua vao UserName
            nguoiDung.setPassword(c.getString(1));//doc truong so 1 dua vao password
            nguoiDung.setPhone(c.getString(2));//doc truong so 2 dua vao phone
            nguoiDung.setFullName(c.getString(3));//doc truong so 3 dua vao fullname
            //them nguoi dung vao danh sach
            arrNguoiDung.add(nguoiDung);
            c.moveToNext();//di chuyen sang ban ghi tiep theo


        }
        c.close();//dong ket noi
        return arrNguoiDung;//tra ve danh sach nguoi dung

    }


}

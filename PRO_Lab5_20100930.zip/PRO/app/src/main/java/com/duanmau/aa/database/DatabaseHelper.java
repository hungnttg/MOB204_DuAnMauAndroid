package com.duanmau.aa.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.duanmau.aa.dao.NguoiDungDao;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="dbBM";
    public static final int VERSION = 1;
    //tao db
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    //tao bang
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(NguoiDungDao.SQL_NGUOI_DUNG);


    }
    //upgrade bang
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ NguoiDungDao.TABLE_NAME);


    }
}

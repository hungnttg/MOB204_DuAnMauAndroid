package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.NguoiDung;

public class NguoiDungDAO {
    //su dung bien csdl
    private SQLiteDatabase db;
    //su dung phan helper vua dinh nghia
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME = "NguoiDung";//ten bang
    //chuoi tao bang nguoi dung
    public static final String SQL_NGUOIDUNG = "CREATE TABLE NguoiDung (" +
            " userName text primary key, " +
            " password text, " +
            " phone text, " +
            " fullName text );";
    //viet phuong thuc khoi tao
    public NguoiDungDAO(Context context)
    {
        //tao moi dbhelper
        dbHelper = new DatabaseHelper(context);
        //cho phep ghi vao bang du lieu
        db =dbHelper.getWritableDatabase();
    }
    //ham insert nguoi dung
    public int insertNguoiDung(NguoiDung nd)
    {
        ContentValues values = new ContentValues();//doi tuong chua du lieu
        values.put("userName",nd.getUserName());//dua username vao doi tuong value
        values.put("password",nd.getPassword());//dua pas vao doi tuong value
        values.put("phone",nd.getPhone());//dua phone vao doi tuong value
        values.put("fullName",nd.getFullName());//dua fullname vao doi tuong value
        try {
            if(db.insert(TABLE_NAME,null,values)==-1)//thuc hien insert
            {
                return -1;//insert khong thanh cong
            }
            else
            {
                return 1;//insert thanh cong
            }
        }
        catch (Exception e)
        {
            Log.e("NguoiDung",e.getMessage());//thong bao loi
        }
        return 1;//insert thanh cong
    }


}

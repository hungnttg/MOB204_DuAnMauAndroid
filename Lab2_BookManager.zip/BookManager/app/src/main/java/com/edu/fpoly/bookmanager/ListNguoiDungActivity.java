package com.edu.fpoly.bookmanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

public class ListNguoiDungActivity extends AppCompatActivity {
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nguoi_dung);
    }

    public void startThemNguoiDung(View view)
    {
        intent = new Intent(ListNguoiDungActivity.this,NguoiDungActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()) {
            case R.id.add:
               // intent = new Intent(ListNguoiDungActivity.this,NguoiDungActivity.class);
               // startActivity(intent);
                return(true);
            case R.id.changePass:
                break;
            case R.id.logOut:

                break;
        }
        return super.onOptionsItemSelected(item);
    }
}

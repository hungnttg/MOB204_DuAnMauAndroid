package com.duanmau.aa.dao;

public class TheLoaiDao {
}

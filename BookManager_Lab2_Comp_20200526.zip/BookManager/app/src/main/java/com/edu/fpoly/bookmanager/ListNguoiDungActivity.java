package com.edu.fpoly.bookmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ListNguoiDungActivity extends AppCompatActivity {
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nguoi_dung);
    }

    public void startThemNguoiDung(View view) {
        intent = new Intent(ListNguoiDungActivity.this,
                NguoiDungActivity.class);
        startActivity(intent);
    }
}

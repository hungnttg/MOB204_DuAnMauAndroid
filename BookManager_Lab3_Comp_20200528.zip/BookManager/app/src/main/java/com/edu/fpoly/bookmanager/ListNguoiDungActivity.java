package com.edu.fpoly.bookmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.edu.fpoly.bookmanager.adapter.NguoiDungAdapter;
import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class ListNguoiDungActivity extends AppCompatActivity {
    ListView lvNguoiDung;
    Intent intent;
    NguoiDungDAO nguoiDungDAO;
    NguoiDungAdapter adapter=null;
    public static List<NguoiDung> ds = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nguoi_dung);
        lvNguoiDung = findViewById(R.id.lvNguoiDung);
        //khoi tao doi tuong DAO
        nguoiDungDAO = new NguoiDungDAO(ListNguoiDungActivity.this);
        ds = nguoiDungDAO.getAllNguoiDung();//lay ve tat ca nguoi dung
        adapter = new NguoiDungAdapter(this,ds);//tao adapter
        lvNguoiDung.setAdapter(adapter);//set Adapter

    }

    public void startThemNguoiDung(View view) {
        intent = new Intent(ListNguoiDungActivity.this,
                NguoiDungActivity.class);
        startActivity(intent);
    }
}

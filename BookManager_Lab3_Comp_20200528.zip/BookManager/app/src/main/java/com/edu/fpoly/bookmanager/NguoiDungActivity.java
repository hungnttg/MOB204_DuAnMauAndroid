package com.edu.fpoly.bookmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

public class NguoiDungActivity extends AppCompatActivity {
    Button btnThemND;
    EditText edUser, edPass, edPhone,edFullname;
    NguoiDungDAO nguoiDungDAO;//khai bao bien nguoidungDao de phuc vu insert
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nguoi_dung);
        //anh xa cac id trong xml vao file java
        btnThemND = findViewById(R.id.btnAddUser);
        edUser = findViewById(R.id.edUserName);
        edPass = findViewById(R.id.edPassword);
        edPhone = findViewById(R.id.edPhone);
        edFullname = findViewById(R.id.edFullName);
    }

    public void addUser(View view) {
        //tao moi nguoiDungDao va truyen context
        nguoiDungDAO = new NguoiDungDAO(NguoiDungActivity.this);
        //dua du lieu tren form vao doi tuong nguoi dung
        NguoiDung nd = new NguoiDung(edUser.getText().toString(),edPass.getText().toString(),
                edPhone.getText().toString(),edFullname.getText().toString());
        try {
            if (nguoiDungDAO.insertNguoiDung(nd)<0)//thuc hien goi ham them du lieu
            {
                //dua ra thonhg bao thanh cong
                Toast.makeText(getApplicationContext(),"Them that bai",Toast.LENGTH_LONG).show();
            }
            else
            {
                //dua ra thong bao that bai
                Toast.makeText(getApplicationContext(),"Them thanh cong",Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e)
        {
            Log.e("NguoiDungActivity: ",e.getMessage());//tra ve thong bao loi neu co loi
        }
    }
}

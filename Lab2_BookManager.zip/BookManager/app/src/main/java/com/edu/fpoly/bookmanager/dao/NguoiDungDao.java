package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.NguoiDung;

public class NguoiDungDao {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME="NguoiDung";
    public static final String SQL_NGUOI_DUNG="CREATE TABLE NguoiDung (" +
            " username text primary key, "+
            " password text, "+
            " phone text, "+
            " hoten text"+
            ");";
    public static final String TAG="NguoiDungDao";
    public NguoiDungDao(Context context)
    {
        dbHelper=new DatabaseHelper(context);
        db=dbHelper.getWritableDatabase();
    }

    public int insertNguoiDung(NguoiDung nd)
    {
        ContentValues values=new ContentValues();
        values.put("username",nd.getUserName());
        values.put("password",nd.getPassword());
        values.put("phone",nd.getPhone());
        values.put("hoten",nd.getHoTen());
        try{
            if(db.insert(TABLE_NAME,null,values)==-1)
            {
                return -1;
            }
        }
        catch (Exception e)
        {
            Log.e(TAG,e.toString());
        }

        return 1;
    }
}

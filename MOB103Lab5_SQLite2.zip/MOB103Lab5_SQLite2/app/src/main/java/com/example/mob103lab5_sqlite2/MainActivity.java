package com.example.mob103lab5_sqlite2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText txtMaLop,txtTenLop;
    Button btnInsert,btnRead;
    ListView listView;
    List<String> listLop = new ArrayList<String>();
    ArrayAdapter<String> adapter;
    LopDal lopDal;
    ///
    //List<Lop> list = new ArrayList<Lop>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //SQLiteHelper sqLiteHelper = new SQLiteHelper(this);
        txtMaLop = findViewById(R.id.tvMaLop);
        txtTenLop = findViewById(R.id.tvTenLop);
        listView = findViewById(R.id.lvLop);
        btnInsert = findViewById(R.id.btnInsert);
        btnRead = findViewById(R.id.btnRead);
         lopDal = new LopDal(MainActivity.this);
        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               List<String> listLop = lopDal.getAllMaLop();
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1, listLop);

                listView.setAdapter(adapter);
            }
        });



        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Lop lop = new Lop();

                lop.setMaLop(txtMaLop.getText().toString());
                lop.setTenLop(txtTenLop.getText().toString());

                //listLop.add(lop.getTenLop());


               if(lopDal.insertLop(lop)<0)
               {
                   Toast.makeText(getApplicationContext(),"Them that bai",Toast.LENGTH_LONG).show();
               }
               else
               {
                   Toast.makeText(getApplicationContext(),"Them Thanh cong",Toast.LENGTH_LONG).show();
               }


            }
        });
    }
}

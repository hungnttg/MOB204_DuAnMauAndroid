package com.duanmau.aa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.duanmau.aa.R;
import com.duanmau.aa.model.NguoiDung;

import java.util.List;

public class RecyclerViewNguoiDungAdapter extends RecyclerView.Adapter<RecyclerViewNguoiDungAdapter.ReViewHolder> {
    private Context context;
    private List<NguoiDung> arrNguoiDung;
    private LayoutInflater inflater;

    public RecyclerViewNguoiDungAdapter(Context context, List<NguoiDung> arrNguoiDung) {
        this.context = context;
        this.arrNguoiDung = arrNguoiDung;
        this.inflater =
                (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public ReViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_nguoi_dung,null);
        ReViewHolder view1 = new ReViewHolder(view);
        view1.ivIcon = (ImageView)view.findViewById(R.id.ivIcon);
        view1.txtPhone = (TextView)view.findViewById(R.id.tvPhone);
        view1.txtName = (TextView)view.findViewById(R.id.tvName);
        view1.imgDelete = (ImageView)view.findViewById(R.id.ivDelete);
        return view1;
    }
    //gan du lieu
    @Override
    public void onBindViewHolder(@NonNull ReViewHolder holder, int position) {
        NguoiDung nguoiDung = arrNguoiDung.get(position);
        holder.txtName.setText(nguoiDung.getHoten());
        holder.txtPhone.setText(nguoiDung.getPhone());
    }

    @Override
    public int getItemCount() {
        return arrNguoiDung.size();
    }

    //dinh nghia lop items
    public class ReViewHolder extends RecyclerView.ViewHolder{
        ImageView ivIcon;
        TextView txtName;
        TextView txtPhone;
        ImageView imgDelete;
        public ReViewHolder(View itemView) {
            super(itemView);
        }
    }
}

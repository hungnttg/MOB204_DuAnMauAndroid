package com.example.mob103lab5_sqlite2;

public class Lop {
    protected String MaLop;
    protected String TenLop;

    public Lop() {
    }

    public Lop(String maLop, String tenLop) {
        MaLop = maLop;
        TenLop = tenLop;
    }

    public String getMaLop() {
        return MaLop;
    }

    public void setMaLop(String maLop) {
        MaLop = maLop;
    }

    public String getTenLop() {
        return TenLop;
    }

    public void setTenLop(String tenLop) {
        TenLop = tenLop;
    }
}

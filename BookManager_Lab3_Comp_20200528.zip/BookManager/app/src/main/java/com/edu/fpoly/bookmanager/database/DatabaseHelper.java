package com.edu.fpoly.bookmanager.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;

public class DatabaseHelper extends SQLiteOpenHelper {
    //khai bao tham so database name
    public static final String DATABASE_NAME="BookManagerDB";
    //khai bao tham so phien ban
    public static final int VERSION=1;
    //ham khoi tao
    public DatabaseHelper(Context context)//truyen ngu canh vao ham khoi tao
    {
        super(context,DATABASE_NAME,null,VERSION);//goi phuong thuc khoi tao
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(NguoiDungDAO.SQL_NGUOIDUNG);//tao bang
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists "+NguoiDungDAO.TABLE_NAME);//xoa bang cu va tao bang moi
    }
}
